arr = list | tuple
ite = list | tuple | str
num = int | float | complex
real = int | float
