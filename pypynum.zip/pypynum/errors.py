"""
Special errors collection
"""


class LogicError(ValueError):
    pass


class RandomError(ValueError):
    pass


class ShapeError(ValueError):
    pass
